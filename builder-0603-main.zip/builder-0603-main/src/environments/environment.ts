// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false
};
const firebaseConfig = {
  apiKey: "AIzaSyBYu4ELUjtVyF_hA53mfSEB7k5pDmcSFMk",
  authDomain: "builder-ac329.firebaseapp.com",
  projectId: "builder-ac329",
  storageBucket: "builder-ac329.appspot.com",
  messagingSenderId: "205981193600",
  appId: "1:205981193600:web:188194b2cf46e9a2ee9d65",
  measurementId: "G-B8YX6KCXSM"
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
