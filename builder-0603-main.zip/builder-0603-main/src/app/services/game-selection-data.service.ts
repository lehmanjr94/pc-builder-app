import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GameSelectionDataService {

  private gameListSource = new BehaviorSubject<Array<number>>([]);
  currentGameList = this.gameListSource.asObservable();
  gameList: Array<number> = [];

  constructor() { }

  changeGameList(gameList: Array<number>) {
    this.gameListSource.next(gameList);
  }
}
