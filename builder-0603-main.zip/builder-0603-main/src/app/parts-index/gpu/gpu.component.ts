import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gpu',
  templateUrl: './gpu.component.html',
  styleUrls: ['./gpu.component.css']
})
export class GpuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
